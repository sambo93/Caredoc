angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})

.controller('MapCtrl', function($scope) {
  var options = {timeout: 10000, enableHighAccuracy: true};
   
    
    
    
  var latLng = new google.maps.LatLng(51.5033640,-0.1276250);
 
    var mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
 
    $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);
 
 
})

;//closes angular


/*
$scope.tryGeoLocation = function(){
  $ionicLoading.show({
    template: 'Getting current position ...'
  });

  // Clean map
  cleanMap();
  $scope.search.input = "";

  $cordovaGeolocation.getCurrentPosition({
    timeout: 10000,
    enableHighAccuracy: true
  }).then(function(position){
    $ionicLoading.hide().then(function(){
      $scope.latitude = position.coords.latitude;
      $scope.longitude = position.coords.longitude;

      createMarker({lat: position.coords.latitude, lng: position.coords.longitude});
    });
  });
};*/
